<?php echo $this->load->view('admin/general/top_scr'); ?>
<?php echo $this->load->view('admin/general/sidebar'); ?>
<?php echo $halaman; ?>
<?php echo $this->load->view('admin/general/footer'); ?>

