<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class menu_resto extends MY_Controller {

    /**
     * Index Page for this controller.
     *
     * Maps to the following URL
     *      http://example.com/index.php/welcome
     *  - or -
     *      http://example.com/index.php/welcome/index
     *  - or -
     * Since this controller is set as the default controller in
     * config/routes.php, it's displayed at http://example.com/
     *
     * So any other public methods not prefixed with an underscore will
     * map to /index.php/welcome/<method_name>
     * @see http://codeigniter.com/user_guide/general/urls.html
     */

    public function __construct()
    {
        parent::__construct();      
        if ($this->session->userdata('astrosession') == FALSE) {
            redirect(base_url('authenticate'));         
        }
        $this->load->library('form_validation');
    }

    //public function index()
    //{
    //  $data['konten'] = $this->load->view('bahan_jadi/daftar_bahan_baku_jadi', NULL, TRUE);
    //  $this->load->view ('main', $data);  
        
    //} 

    //------------------------------------------ View Data Table----------------- --------------------//
    
  //  public function index()
//{
//        $data['aktif']='master';
//$data['konten'] = $this->load->view('bahan_baku/daftar_bahan_baku', NULL, TRUE);
//$data['halaman'] = $this->load->view('bahan_baku/menu', $data, TRUE);
//$this->load->view('bahan_baku/main', $data);	
//
//}
    
    public function menu()
    {
        $data['aktif'] = 'master';
        $data['konten'] = $this->load->view('master/menu', NULL, TRUE);
        $this->load->view ('main', $data);      
    }

    public function rak()
    {
        $data['aktif'] = 'master';
        $data['konten'] = $this->load->view('rak/daftar_rak', NULL, TRUE);
        $data['halaman'] = $this->load->view('rak/menu', $data, TRUE);
        $this->load->view('rak/main', $data);       
    }

    public function daftar_menu()
    {

        /*$data['konten'] = $this->load->view('setting/daftar', NULL, TRUE);
        $this->load->view ('main', $data);*/

        $data['aktif'] = 'master';
        $data['konten'] = $this->load->view('menu_resto/daftar_menu', NULL, TRUE);
        $data['halaman'] = $this->load->view('menu_resto/menu', $data, TRUE);
        $this->load->view('menu_resto/main', $data);       
    }

    

    public function detail()
    {
        $data['aktif'] = 'master';
        $data['konten'] = $this->load->view('menu_resto/detail_menu', NULL, TRUE);
        $data['halaman'] = $this->load->view('menu_resto/menu', $data, TRUE);
        $this->load->view('menu_resto/main', $data);
        
            
    }  

    //------------------------------------------ View Input----------------- --------------------//
    
    public function tambah()
    {
        $data['aktif'] = 'master';
        $data['konten'] = $this->load->view('menu_resto/tambah_menu', NULL, TRUE);
        $data['halaman'] = $this->load->view('menu_resto/menu', $data, TRUE);
        $this->load->view('menu_resto/main', $data);  
    } 

    //------------------------------------------ Proses Simpan----------------- --------------------//
   

    public function simpan_tambah_menu() {
        $this->load->library('form_validation');
        $this->form_validation->set_rules('kode_menu', 'temp', 'required');
        $this->form_validation->set_rules('nama_menu', 'temp', 'required');
        $this->form_validation->set_rules('kode_kategori_menu', 'temp', 'required');
        $this->form_validation->set_rules('harga_jual', 'temp', 'required');
        $this->form_validation->set_rules('kode_satuan_stok', 'temp', 'required');
        $this->form_validation->set_rules('status_menu', 'temp', 'required');

        if ($this->form_validation->run() == FALSE) {
            echo '<div class="alert alert-warning">Gagal tersimpan.</div>';            
        } else {
            $simpan_menu = $this->input->post();
            
            $nama_satuan_stok = $this->db->get_where('master_satuan',array('kode'=>$simpan_menu['kode_satuan_stok']));
            $hasil_nama = $nama_satuan_stok->row();
            $simpan_menu['satuan_stok'] = $hasil_nama->nama;
            
            $nama_kategori = $this->db->get_where('master_kategori_menu',array('kode_kategori_menu'=>$simpan_menu['kode_kategori_menu']));
            $hasil_nama_kat = $nama_kategori->row();
            
            $simpan_menu['kategori_menu'] = $hasil_nama_kat->nama_kategori_menu;
            
            $this->db->insert('master_menu',$simpan_menu);
            echo '<div class="alert alert-success">Sudah tersimpan.</div>';    
        }    
    }
    
    //------------------------------------------ Proses Update----------------- --------------------//
    

    

    public function simpan_edit_menu() {
        $this->load->library('form_validation');
        $this->form_validation->set_rules('kode_menu', 'temp', 'required');
        $this->form_validation->set_rules('nama_menu', 'temp', 'required');
        $this->form_validation->set_rules('kode_kategori_menu', 'temp', 'required');
        $this->form_validation->set_rules('harga_jual', 'temp', 'required');
        $this->form_validation->set_rules('kode_satuan_stok', 'temp', 'required');
        $this->form_validation->set_rules('status_menu', 'temp', 'required');

        if ($this->form_validation->run() == FALSE) {
            echo '<div class="alert alert-warning">Gagal tersimpan.</div>';            
        } else {
            $simpan_menu = $this->input->post();
            
            $nama_satuan_stok = $this->db->get_where('master_satuan',array('kode'=>$simpan_menu['kode_satuan_stok']));
            $hasil_nama = $nama_satuan_stok->row();
            $simpan_menu['satuan_stok'] = $hasil_nama->nama;
            
            $nama_kategori = $this->db->get_where('master_kategori_menu',array('kode_kategori_menu'=>$simpan_menu['kode_kategori_menu']));
            $hasil_nama_kat = $nama_kategori->row();
            
            $simpan_menu['kategori_menu'] = $hasil_nama_kat->nama_kategori_menu;
            
            $this->db->update('master_menu',$simpan_menu,array('kode_menu'=>$simpan_menu['kode_menu']));
            echo '<div class="alert alert-success">Sudah tersimpan.</div>';    
        }    
    }

    public function get_kode()
    {
        $kode_menu = $this->input->post('kode_menu');
        $query = $this->db->get_where('master_menu',array('kode_menu' => $kode_menu))->num_rows();

        if($query > 0){
            echo "1";
        }
        else{
            echo "0";
        }
    }

    //------------------------------------------ Proses Delete----------------- --------------------//
    public function hapus(){
        $id = $this->input->post('id');

        $kode_menu = $this->uri->segment(4);

        $query = $this->db->get_where('opsi_menu_temp',array('id_menu'=>$id,'kode_menu' => $kode_menu));
        $data = $query->row();

        $kode_menu_opsi = $data->kode_menu;
        $kode_bahan_opsi = $data->kode_bahan;

        //echo $kode_bahan_opsi;

        $delete = $this->db->delete('opsi_menu_temp',array('id_menu'=>$id));

        $get_opsi_menu = $this->db->get_where('opsi_menu',array('kode_menu'=>$kode_menu_opsi,'kode_bahan'=>$kode_bahan_opsi));
        $get_opsi_menu = $get_opsi_menu->row();
        $total = count($data);
        //echo $total;
        if($total > 0){
            $this->db->delete('opsi_menu',array('kode_menu'=>$get_opsi_menu->kode_menu,'kode_bahan'=>$get_opsi_menu->kode_bahan));
        }
    }

    public function hapus_bahan_jadi(){
        $id = $this->input->post('id');
        //$this->db->delete('master_bahan_jadi',array('id'=>$id));

        $where = array('kode_menu' => $id);

        $query = $this->db->get_where('master_menu',array('kode_menu' => $id));
        $data = $query->row();

        $delete = $this->db->delete('master_menu',array('kode_menu' => $id));
        if($delete){
            $query = $this->db->get_where('opsi_menu',array('kode_menu'=>$data->kode_menu));
            $data = $query->row();
            $total = count($data);
            if($total > 0){
                $this->db->delete('opsi_menu',array('kode_menu'=>$data->kode_menu));
            }
            echo "1|".succ_msg("Menu berhasil dihapus.");
        } else {
            echo "0|".err_msg("Gagal, coba periksa lagi inputan anda.");
        }
    }

    public function get_satuan()
    {
        $kode_bahan = $this->input->post('kode_bahan');
        $opt = '';
        $data = $this->db->get_where('master_bahan_baku',array('kode_bahan_baku' => $kode_bahan));
        foreach ($data->result() as $key => $value) {
            $opt .= "<option value=".$value->id_satuan_stok.">".$value->satuan_stok."</option>";
        }
            //echo $opt;

        $data = $this->db->get_where('master_bahan_jadi',array('kode_bahan_jadi' => $kode_bahan));
        foreach ($data->result() as $key => $value) {
            $opt .= "<option value=".$value->kode_satuan_stok.">".$value->satuan_stok."</option>";
        }
            echo $opt;
    }

    public function get_rak()
    {
        $kode_unit = $this->input->post('kode_unit');
        $opt = "<option selected='true' value=''>--Pilih Rak--</option>";
        $data = $this->db->get_where('master_rak',array('kode_unit' => $kode_unit));
        foreach ($data->result() as $key => $value) {
            $opt .= "<option value=".$value->kode_rak.">".$value->nama_rak."</option>";
        }
            echo $opt;
    }

    public function get_produk()
    {
        $param = $this->input->post();
        $jenis = $param['jenis_bahan'];
        $kode_rak = $param['kode_rak'];
        if($jenis == 'Bahan Baku'){
            $opt = '';
            #$this->db->where('kode_rak',$kode_rak);
            $this->db->group_by('kode_bahan_baku');
            $query = $this->db->get('master_bahan_baku');
                $opt = '<option value="">--Pilih Bahan Baku--</option>';
                foreach ($query->result() as $key => $value) {
                    $opt .= '<option value="'.$value->kode_bahan_baku.'">'.$value->nama_bahan_baku.'</option>';  
                }
            echo $opt;
            
        }else if ($jenis == 'Bahan Jadi') {
            $opt = '';
           # $this->db->where('kode_rak',$kode_rak);
           $this->db->group_by('kode_bahan_jadi');
            $query = $this->db->get('master_bahan_jadi');
                $opt = '<option value="">--Pilih Bahan Jadi--</option>';
                foreach ($query->result() as $key => $value) {
                    $opt .= '<option value="'.$value->kode_bahan_jadi.'">'.$value->nama_bahan_jadi.'</option>';  
                }
            echo $opt.$this->db->last_query();
        }
    }

    public function get_komposisi(){
        $id = $this->input->post('id_opsi_menu');
        $komposisi = $this->db->get_where('opsi_menu_temp',array('id_menu'=>$id));
        $hasil = $komposisi->row();
        echo json_encode($hasil);
    }
    
    public function get_bahan(){
        $bahan_baku = $this->db->get('master_bahan_baku');
        $hasil_bahan_baku = $bahan_baku->result();
        $opt = '';
        foreach($hasil_bahan_baku as $item){
            $bahan_baku_temp = $this->db->get_where('opsi_bahan_jadi_temp',array('kode_bahan_baku'=>$item->kode_bahan_baku));
            $hasil_bahan_baku_temp = $bahan_baku_temp->row();
                if(count($hasil_bahan_baku_temp)<1){
                    $opt.="<option value='$item->kode_bahan_baku'>$item->nama_bahan_baku</option>";
                } 
        }
        echo "<option selected='true' value=''>--Pilih Bahan Baku--</option>".$opt;
        
        $bahan_jadi = $this->db->get('master_bahan_jadi');
        $hasil_bahan_jadi = $bahan_jadi->result();
        $opt = '';
        foreach($hasil_bahan_jadi as $item){
            $bahan_jadi_temp = $this->db->get_where('opsi_bahan_jadi_temp',array('kode_bahan_jadi'=>$item->kode_bahan_jadi));
            $hasil_bahan_jadi_temp = $bahan_jadi_temp->row();
                if(count($hasil_bahan_jadi_temp)<1){
                    $opt.="<option value='$item->kode_bahan_jadi'>$item->nama_bahan_jadi</option>";
                } 
        }
        echo "<option selected='true' value=''>--Pilih Bahan Jadi--</option>".$opt;                              
                                  
    }

}
