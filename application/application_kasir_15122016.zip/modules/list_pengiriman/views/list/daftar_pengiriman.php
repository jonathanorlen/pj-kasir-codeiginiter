 <section class="content-header">
    <div class="page-bar">
      <ul class="page-breadcrumb">
        <li>
          <i class="fa fa-home"></i>
          <a href="#">List Pengiriman</a>
          <i class="fa fa-angle-right"></i>
        </li>
        <li>
          <a href="#">Daftar Pengiriman</a>
          <i class="fa fa-angle-right"></i>
        </li>
      </ul>
    </div>
  </section>

<div class="row">      
  <div class="col-xs-12">
    <div class="portlet box blue">
      <div class="portlet-title">
        <div class="caption">
          List Pengiriman
        </div>
        <div class="tools">
          <a href="javascript:;" class="collapse">
          </a>
          <a href="javascript:;" class="reload">
          </a>
        </div>
      </div>
      <div class="portlet-body">
        <div class="box-body">            
          <div class="sukses" ></div>
          <table  class="table table-striped table-hover table-bordered" id="tabel_daftar"  style="font-size:1.5em;">
            <?php
                $pengiriman = $this->db->get_where('transaksi_penjualan',array('status_penerimaan' => 'dikirim'));
                $list_pengiriman = $pengiriman->result();
            ?>
            <thead>
              <tr width="100%">
                <th>No</th>
                <th>Kode Transaksi</th>
                <th>Tanggal Kirim</th>
                <th>Status Transaksi</th>
                <th width="10%">Action</th>
              </tr>
            </thead>
            <tbody>
              <?php
                  $nomor=1;
                  foreach($list_pengiriman as $list){
              ?>
                <tr>
                  <td><?php echo $nomor; ?></td>
                  <td><?php echo $list->kode_transaksi; ?></td>
                  <td><?php echo TanggalIndo($list->tanggal_pengiriman); ?></td>
                  <td><?php echo cek_status_pengiriman($list->status); ?></td>
                  <td><?php echo get_detail($list->id); ?></td>
                </tr>
                <?php $nomor++; } ?>
              </tbody>
              <tfoot>
                <tr width="100%">
                <th>No</th>
                <th>Kode Transaksi</th>
                <th>Tanggal Kirim</th>
                <th>Status Transaksi</th>
                <th width="10%">Action</th>
              </tr>
             </tfoot>
           </table>
         </div>
       </div>
     </div>
   </div>
 </div>
</div>    
</div>  

<style type="text/css" media="screen">
  .btn-back
  {
    position: fixed;
    bottom: 10px;
    left: 10px;
    z-index: 999999999999999;
    vertical-align: middle;
    cursor:pointer
  }
</style>
<img class="btn-back" src="<?php echo base_url().'component/img/back_icon.png'?>" style="width: 70px;height: 70px;">

<script>
  $('.btn-back').click(function(){
    $(".tunggu").show();
    window.location = "<?php echo base_url().'admin/template'; ?>";
  });
</script>
