<?php
if(@$kode){
	$order = $this->db->get_where('opsi_transaksi_penjualan_temp',array('kode_meja'=>$kode,'status !='=>'personal'));
	$list_order = $order->result();
	$nomor = 1;  
	foreach($list_order as $daftar){ 
		?> 
		<tr>
			<td><?php echo $nomor; ?></td>
			<td><?php echo @$daftar->nama_menu; ?></td>
			<td align="center"><?php echo @$daftar->jumlah; ?></td>
			<td><?php echo format_rupiah(@$daftar->harga_satuan); ?></td>
			<td><?php echo format_rupiah(@$daftar->subtotal); ?></td>
			<td align="center"><?php echo @$daftar->diskon_item; ?></td>
			<td align="center"><?php echo get_del_id(@$daftar->id); ?></td>
		</tr>
		<?php 
		$nomor++; 
	} }
	?>